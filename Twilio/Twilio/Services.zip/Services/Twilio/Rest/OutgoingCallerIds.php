<?php

class Services_Twilio_Rest_OutgoingCallerIds
    extends Services_Twilio_ListResource
{
}
